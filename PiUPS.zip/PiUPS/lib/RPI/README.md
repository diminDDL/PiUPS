this librarys are made based on a this dimensions of raspberry file
http://www.raspiworld.com/images/other/drawings/Raspberry-Pi-1-2-3-Model-B.pdf

If you need help, comment and I'll answer as quickly as possible

https://i.imgur.com/jruPSif.png

![alt text](https://i.imgur.com/jruPSif.png)

https://i.imgur.com/ugdHz6m.png

![alt text](https://i.imgur.com/ugdHz6m.png)

based on the library of https://github.com/Tinkerforge but this is more useful for me
